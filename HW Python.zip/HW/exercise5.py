Python 3.7.0a2 (v3.7.0a2:f7ac4fe52a, Oct 16 2017, 21:11:18) 
[GCC 4.2.1 (Apple Inc. build 5666) (dot 3)] on darwin
Type "copyright", "credits" or "license()" for more information.
>>> WARNING: The version of Tcl/Tk (8.5.9) in use may be unstable.
Visit http://www.python.org/download/mac/tcltk/ for current information.
number = 0
>>> x = 11
>>> while number < 20:
	number += 1
	x += 1
	if (x%5==0) or (x%7==0) or (x%11==0):
		print (x)

		
14
15
20
21
22
25
28
30
>>> 
