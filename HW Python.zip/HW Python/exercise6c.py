Python 3.7.0a2 (v3.7.0a2:f7ac4fe52a, Oct 16 2017, 21:11:18) 
[GCC 4.2.1 (Apple Inc. build 5666) (dot 3)] on darwin
Type "copyright", "credits" or "license()" for more information.
>>> WARNING: The version of Tcl/Tk (8.5.9) in use may be unstable.
Visit http://www.python.org/download/mac/tcltk/ for current information.
for num in range(1,100):    prime = True    for n in range(2,num):        if (num%n==0):            prime = False    if prime:       print(num)
1
2
3
5
7
11
13
17
19
23
29
31
37
41
43
47
53
59
61
67
71
73
79
83
89
97
>>> 
