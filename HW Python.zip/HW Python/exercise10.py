import numpy as np
import matplotlib.pylab as py
x = np.linspace(0,2)
y1 = np.sin(x-2)**2
y2 = np.exp(-(x**2))
y = y1*y2
py.plot(x,y,'Plot')
py.xlabel('Interval')
py.ylabel('Functions - f(x)')
py.title('plotting \'matplotlib\'') 
py.show()
